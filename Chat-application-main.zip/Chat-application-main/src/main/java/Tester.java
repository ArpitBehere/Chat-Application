public class Tester {
	
	public static void main(String[] args) {
		
		
		// please give ternary operator example
		int a = 100;
		int b = 20;
		//int max = (a > b) ? a : b;
		
		int max;
		if(a>b) {
			max = a;
		} else {
			max = b;
		}
		System.out.println("The maximum value is: " + max);
		
		
		
		
	}

}
